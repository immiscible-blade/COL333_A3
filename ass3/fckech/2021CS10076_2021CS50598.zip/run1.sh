#!/bin/bash
./orgstosat "$1.graph" "$1.satinput"