#!/bin/bash
g++ -Wall inputmaker3.cpp orgstosat.cpp -o orgstosat
g++ -Wall satorgs.cpp -o satorgs
g++ -Wall satorgs_p2.cpp -o satorgs_p2
g++ -Wall orgtosat_p2.cpp -o orgtosat_p2