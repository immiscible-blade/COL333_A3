#!/bin/bash
./satorgs "$1.graph" "$1.satoutput" "$1.mapping"